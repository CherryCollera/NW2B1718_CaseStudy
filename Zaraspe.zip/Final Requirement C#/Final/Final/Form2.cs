﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final
{
    public partial class Form2 : Form
    {

        private OleDbConnection con;
        private OleDbCommand cmd = new OleDbCommand();

        private string connParam =
                @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Drin\Desktop\Final Requirement\Final\Final\db\flowershopdb.accdb";

        public Form2()
        {
            con = new OleDbConnection(connParam);

            InitializeComponent();
        }



        private void Form2_Load(object sender, EventArgs e)
        {

            // TODO: This line of code loads data into the 'flowershopdbDataSet1.flowershopdb' table. You can move, or remove it, as needed.
            this.flowershopdbTableAdapter1.Fill(this.flowershopdbDataSet1.flowershopdb);


        }





        private void btnAdd_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert into flowershopdb (Name, Description, Unit_Price, Stocks) values ('" + this.tbName.Text + "','" + this.tbDescription.Text + "', '" + this.tbUnit_Price.Text + "', '" + this.tbStocks.Text + "');";
            int temp = cmd.ExecuteNonQuery();
            if (temp > 0)
            {
                tbName.Text = null;
                tbDescription.Text = null;
                tbUnit_Price.Text = null;
                tbStocks.Text = null;
                MessageBox.Show("Record Successfuly Added");
            }
            else
            {
                MessageBox.Show("Record Successfuly Added");
            }
            con.Close();
        }




        private void btnView_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM flowershopdb", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("SELECT * FROM flowershopdb", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                    dataTable.Rows[i][1], dataTable.Rows[i][2], dataTable.Rows[i][3], dataTable.Rows[i][4]);
            }
        }




        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "delete from flowershopdb where Name='" + tbName.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Successfully Deleted");
        }





        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewCell cell = null;
            foreach (DataGridViewCell selectedCell in dataGridView1.SelectedCells)
            {
                cell = selectedCell;
                break;
            }
            if (cell != null)
            {
                DataGridViewRow row = cell.OwningRow;
                tbName.Text = row.Cells[1].Value.ToString();
                tbDescription.Text = row.Cells[2].Value.ToString();
                tbUnit_Price.Text = row.Cells[3].Value.ToString();
                tbStocks.Text = row.Cells[4].Value.ToString();
            }
        }



        public void cleartxtbox()
        {
            tbName.Text = "";
            tbDescription.Text = "";
            tbUnit_Price.Text = "";
            tbStocks.Text = "";

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cleartxtbox();
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            tbName.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            tbDescription.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            tbUnit_Price.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            tbStocks.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
        }
        

        //UPDATE BUTTON
        //Update button only updates the stocks of the flowers
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "update flowershopdb set Stocks='"+tbStocks.Text+"' where Name='" + tbName.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Updated!");
        }





        private void tbName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report report = new Report();
            report.Show();
        }
    }
}
