﻿namespace Final
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.flowershopdbBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flowershopdbDataSet = new Final.flowershopdbDataSet();
            this.flowershopdbTableAdapter = new Final.flowershopdbDataSetTableAdapters.flowershopdbTableAdapter();
            this.flowershopdbDataSet1 = new Final.flowershopdbDataSet1();
            this.flowershopdbDataSet2 = new Final.flowershopdbDataSet2();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.flowershopdbBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flowershopdbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flowershopdbDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flowershopdbDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // flowershopdbBindingSource
            // 
            this.flowershopdbBindingSource.DataMember = "flowershopdb";
            this.flowershopdbBindingSource.DataSource = this.flowershopdbDataSet;
            // 
            // flowershopdbDataSet
            // 
            this.flowershopdbDataSet.DataSetName = "flowershopdbDataSet";
            this.flowershopdbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // flowershopdbTableAdapter
            // 
            this.flowershopdbTableAdapter.ClearBeforeFill = true;
            // 
            // flowershopdbDataSet1
            // 
            this.flowershopdbDataSet1.DataSetName = "flowershopdbDataSet1";
            this.flowershopdbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // flowershopdbDataSet2
            // 
            this.flowershopdbDataSet2.DataSetName = "flowershopdbDataSet2";
            this.flowershopdbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.flowershopdbBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Final.Report4.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(69, 110);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(922, 559);
            this.reportViewer1.TabIndex = 0;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 745);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Report";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Report";
            this.Load += new System.EventHandler(this.Report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.flowershopdbBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flowershopdbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flowershopdbDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flowershopdbDataSet2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource flowershopdbBindingSource;
        private flowershopdbDataSet flowershopdbDataSet;
        private flowershopdbDataSetTableAdapters.flowershopdbTableAdapter flowershopdbTableAdapter;
        private flowershopdbDataSet1 flowershopdbDataSet1;
        private flowershopdbDataSet2 flowershopdbDataSet2;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
    }
}